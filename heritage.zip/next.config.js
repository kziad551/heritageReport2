/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['heritage.top-wp.com'],
      },
}

module.exports = nextConfig
